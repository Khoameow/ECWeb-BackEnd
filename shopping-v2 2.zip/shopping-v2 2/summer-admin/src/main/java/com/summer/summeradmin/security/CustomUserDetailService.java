package com.summer.summeradmin.security;

import com.summer.summercore.dto.AuthDTO;
import com.summer.summercore.dto.MyUser;
import com.summer.summercore.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@Service
@Transactional
public class CustomUserDetailService implements UserDetailsService {

    @Autowired
    private AuthService authService;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AuthDTO authDto = authService.findOneByUsername(username);
        if(null == authDto){
            throw new UsernameNotFoundException("");
        }
        List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
        if(authDto.getUsername().equalsIgnoreCase("admin")){
            grantedAuthorityList.add(new SimpleGrantedAuthority("ADMIN"));
        }
        else {
            grantedAuthorityList.add(new SimpleGrantedAuthority("USER"));
        }

        MyUser myUser = new MyUser(authDto.getUsername(), authDto.getPassword(),true,true,true,true,grantedAuthorityList);
        myUser.setFullname("");
        return myUser;
    }
}
