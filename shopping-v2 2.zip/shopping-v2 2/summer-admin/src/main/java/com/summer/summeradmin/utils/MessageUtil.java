package com.summer.summeradmin.utils;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class MessageUtil {
    public Map<String,String> getMessage(String message){
        Map<String,String> result = new HashMap<>();

        if(message.equals("update_success")){
            result.put("message","Cập nhật thành công");
            result.put("alert","alert alert-success");
        }
        else if(message.equals("insert_success")){
            result.put("message","Tạo mới thành công");
            result.put("alert","alert alert-success");
        }
        else if(message.equals("error_system")){
            result.put("message","Lỗi hệ thống");
            result.put("alert","alert alert-danger");
        }
        else if(message.equals("delete_success")){
            result.put("message","Xóa thành công");
            result.put("alert","alert alert-success");
        }
        else if(message.equals("account_exist")){
            result.put("message","Tên tài khoản đã tồn tại");
            result.put("alert","alert alert-danger");
        }
        else if(message.equals("register-success")){
            result.put("message","Đăng ký thành công");
            result.put("alert","alert alert-success");
        }
        else if(message.equals("register-error")){
            result.put("message","Tên tài khoản đã tồn tại");
            result.put("alert","alert alert-danger");
        }

        else if(message.equals("change_password_success")){
            result.put("message","Đổi mật khẩu thành công");
            result.put("alert","alert alert-success");
        }
        else if(message.equals("wrong_password")){
            result.put("message","Sai mật khẩu hiện tại");
            result.put("alert","alert alert-danger");
        }
        else if(message.equals("2password_not_equal")){
            result.put("message","Xác nhận mật khẩu không khớp nhau");
            result.put("alert","alert alert-danger");
        }
        else if(message.equals("validate_code")){
            result.put("message","Field not empty");
            result.put("alert","alert alert-danger");
        }


        return result;
    }
}
