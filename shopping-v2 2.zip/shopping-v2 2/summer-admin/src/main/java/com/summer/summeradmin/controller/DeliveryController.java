package com.summer.summeradmin.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.summer.summeradmin.constant.AdminConstant;
import com.summer.summercore.dto.DeliveryDTO;
import com.summer.summercore.service.DeliveryService;

@RestController
@RequestMapping(value = AdminConstant.ROOT)
public class DeliveryController {

	@Autowired
	private DeliveryService deliveryService;
	
	@GetMapping(value = "/delivery/list")
	public ModelAndView listProduct() {
		ModelAndView mav = new ModelAndView("views/delivery/list");
		List<DeliveryDTO> listResults = deliveryService.getAllDelivery();
		mav.addObject("listResults", listResults);
		return mav;
	}
	
	@GetMapping(value = "/delivery/status")
    public ModelAndView updateDeliveryStatus(
            @RequestParam(value = "id",required = false) Long id,
            @RequestParam(value = "status",required = false) Long status) {		
        ModelAndView mav = new ModelAndView("views/delivery/list");        
        DeliveryDTO deliveryDTO = new DeliveryDTO();
        if(Objects.nonNull(id)) {
        	deliveryDTO = deliveryService.findOneByDeliveryId(id);
        	if(status != null){
        		deliveryDTO.setStatus(status.intValue());
        	}
        	deliveryService.updateStatus(deliveryDTO);	
        }                   
        List<DeliveryDTO> listResults = deliveryService.getAllDelivery();
		mav.addObject("listResults", listResults);  
        return mav;
    }
    	 
}
