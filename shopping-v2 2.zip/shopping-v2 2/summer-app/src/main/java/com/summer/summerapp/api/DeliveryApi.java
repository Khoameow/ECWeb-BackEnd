package com.summer.summerapp.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.summer.summerapp.constant.AppConstant;
import com.summer.summercore.dto.DeliveryDTO;
import com.summer.summercore.entity.Delivery;
import com.summer.summercore.service.DeliveryService;


@RestController
@CrossOrigin
@RequestMapping(AppConstant.ROOT + AppConstant.DELIVERY)
public class DeliveryApi {

    
    @Autowired
	private DeliveryService deliveryService;




    @PostMapping("/insertdelivery")
    public ResponseEntity<Delivery> insertDelivery(@RequestBody DeliveryDTO deliveryDTO){
    	Delivery result = null;
        HttpStatus status = HttpStatus.OK;
        try {
        	
        	 result = deliveryService.Store(deliveryDTO);
        	
        } catch (Throwable e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            e.printStackTrace();
        }
        return new ResponseEntity<>(result, status);
    }
    
    @GetMapping("/getdeliverybyid")
    public ResponseEntity<DeliveryDTO> getDeliverybyId(Long deliveryId){
    	DeliveryDTO result = null;
        HttpStatus status = HttpStatus.OK;
        try {
        	
        	 result = deliveryService.getDeliverybyIds(deliveryId);
        	
        } catch (Throwable e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            e.printStackTrace();
        }
        return new ResponseEntity<>(result, status);
    }
    
    @GetMapping("/getdeliverybyusername")
    public ResponseEntity<DeliveryDTO[]> getDeliverybyUserName(String userName){
    	DeliveryDTO[] result = null;
        HttpStatus status = HttpStatus.OK;
        try {
        	
        	 result = deliveryService.getDeliverybyUserName(userName).toArray(DeliveryDTO[] ::new);
        	
        } catch (Throwable e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            e.printStackTrace();
        }
        return new ResponseEntity<>(result, status);
    }
}

