package com.summer.summerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;

@SpringBootApplication
@ComponentScan(value = {"com.summer.summerapp","com.summer.summercore"})
@EnableJdbcRepositories(basePackages={"com.summer.summercore.repository"})
public class SummerApp {

    public static void main(String[] args) {
        SpringApplication.run(SummerApp.class, args);
    }

}
