package com.summer.summerapp.api;

import com.summer.summerapp.constant.AppConstant;
import com.summer.summercore.dto.ProductDTO;
import com.summer.summercore.entity.*;
import com.summer.summercore.service.ManufactureService;
import com.summer.summercore.service.ProductService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(AppConstant.ROOT + AppConstant.PRODUCT)
@Api(tags = AppConstant.PRODUCT)
public class ProductApi {

	Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ProductService productService;
	
	@Autowired
	private ManufactureService manufactureService;

	@ApiOperation(value = "Search Product", produces = "application/json")
	@GetMapping(value = AppConstant.LIST)
	public ResponseEntity<?> listAccount(@ApiIgnore @RequestParam MultiValueMap<String, String> requestParams,
			@ApiIgnore Pageable pageable) {
		return ResponseEntity.ok().header("Access-Control-Allow-Origin", "*").body("test api");
	}

	@GetMapping("/getallproduct")
	public ResponseEntity<ProductDTO[]> getAllProduct() {
		ProductDTO[] result = null;
		HttpStatus status = HttpStatus.OK;
		try {

			List<ProductDTO> listProduct = productService.findAllProduct(100, 0);
			List<ProductDTO> lstResult = new ArrayList<>();
			for (var item : listProduct) {
				ProductDTO dto = new ProductDTO();
				dto.setProductId(item.getProductId());
				List<Image> lstImage = productService.findImageByProductId(item.getProductId());
				if (lstImage.size() > 0) {
					dto.setImagePresent(lstImage.get(0).getImageLink());
				}
				dto.setDecription(item.getDecription());
				List<Rating> lstRating = productService.findRatingbyProductId(item.getProductId());
				if (lstRating.size() > 0) {
					dto.setRatingValue(lstRating.get(0).getRatingValue());
				}
				List<Price> lstPrice = productService.findPriceByProductId(item.getProductId());
				if (lstPrice.size() > 0) {
					dto.setPriceValue(lstPrice.get(0).getPriceOut());
				}
				dto.setProductName(item.getProductName());
				lstResult.add(dto);
			}
			result = lstResult.toArray(ProductDTO[]::new);
		} catch (Throwable e) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			e.printStackTrace();
		}
		return new ResponseEntity<>(result, status);
	}

	@GetMapping("/getproductdetail")
	public ResponseEntity<ProductDTO> getProductDetail(Long productId) {
		ProductDTO result = null;
		HttpStatus status = HttpStatus.OK;
		try {

			Product product = productService.getProductById(productId);

			ProductDTO dto = new ProductDTO();
			dto.setProductId(product.getProductId());
			List<Image> lstImage = productService.findImageByProductId(product.getProductId());
			if (lstImage.size() > 0) {
				dto.setImagePresent(lstImage.get(0).getImageLink());
			}
			dto.setDecription(product.getDecription());
			List<Rating> lstRating = productService.findRatingbyProductId(product.getProductId());
			if (lstRating.size() > 0) {
				dto.setRatingValue(lstRating.get(0).getRatingValue());
			}
			List<Price> lstPrice = productService.findPriceByProductId(product.getProductId());
			if (lstPrice.size() > 0) {
				dto.setPriceValue(lstPrice.get(0).getPriceOut());
			}
			
			dto.setProductName(product.getProductName());
			Manufacture manu = manufactureService.getManufactureById(product.getManufactureId());
			if(manu != null) {
				dto.setManufactureName(manu.getManufactureName());
			}
//			Manufacture manu = manufactureService.getManufactureById(product.getManufactureId());
//			if(manu != null) {
//				dto.setManufactureName(manu.getManufactureName());
//			}
			
			List<Stock> lstStock = productService.findStockByProductId(product.getProductId());
			if (lstStock.size() > 0) {
				dto.setStockTotal(lstStock.get(0).getTotal());
			}
			result = dto;
		} catch (Throwable e) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			e.printStackTrace();
		}
		return new ResponseEntity<>(result, status);
	}

	@GetMapping("/getproductpresent")
	public ResponseEntity<ProductDTO[]> getProductPresent() {
		ProductDTO[] result = null;
		HttpStatus status = HttpStatus.OK;
		try {
			var productPresent = productService.findAllProductPresent();
			List<Integer> listId = productPresent.stream().map(x -> Integer.parseInt(String.valueOf(x.getProductId())))
					.collect(Collectors.toList());
			var listProduct = productService.findAllProductByIds(listId);
			List<ProductDTO> lstResult = new ArrayList<>();

			for (var item : listProduct) {
				ProductDTO dto = new ProductDTO();
				dto.setProductId(item.getProductId());
				List<Image> lstImage = productService.findImageByProductId(item.getProductId());
				if (lstImage.size() > 0) {
					dto.setImagePresent(lstImage.get(0).getImageLink());
				}
				lstResult.add(dto);
			}
			result = lstResult.toArray(ProductDTO[]::new);
		} catch (Throwable e) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			e.printStackTrace();
		}
		return new ResponseEntity<>(result, status);
	}
	
	@GetMapping("/getproductbycategoryId")
	public ResponseEntity<ProductDTO[]> getProductByCategoryId(Long categoryId) {
		ProductDTO[] result = new ProductDTO[0];
		HttpStatus status = HttpStatus.OK;
		try {

			List<ProductDTO> listProductCate = productService.findAllProductByCategoryId(categoryId, 100, 0);
			List<Integer> lstProductId = listProductCate.stream().map(x ->Integer.parseInt(String.valueOf(x.getProductId()))).collect(Collectors.toList());
			if(lstProductId.size()> 0) {
				List<Product> listProduct = productService.findAllProductByIds(lstProductId);
				List<ProductDTO> lstResult = new ArrayList<>();
				for (var item : listProduct) {
					ProductDTO dto = new ProductDTO();
					dto.setProductId(item.getProductId());
					List<Image> lstImage = productService.findImageByProductId(item.getProductId());
					if (lstImage.size() > 0) {
						dto.setImagePresent(lstImage.get(0).getImageLink());
					}
					dto.setDecription(item.getDecription());
					List<Rating> lstRating = productService.findRatingbyProductId(item.getProductId());
					if (lstRating.size() > 0) {
						dto.setRatingValue(lstRating.get(0).getRatingValue());
					}
					List<Price> lstPrice = productService.findPriceByProductId(item.getProductId());
					if (lstPrice.size() > 0) {
						dto.setPriceValue(lstPrice.get(0).getPriceOut());
					}
					dto.setProductName(item.getProductName());
					lstResult.add(dto);
				}
				result = lstResult.toArray(ProductDTO[]::new);
			}
			
			
		} catch (Throwable e) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
			e.printStackTrace();
		}
		return new ResponseEntity<>(result, status);
	}
	

}
