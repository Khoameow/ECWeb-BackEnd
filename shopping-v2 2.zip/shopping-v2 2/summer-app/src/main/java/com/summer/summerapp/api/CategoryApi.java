package com.summer.summerapp.api;

import com.summer.summerapp.constant.AppConstant;
import com.summer.summerapp.jwt.JwtUtils;
import com.summer.summerapp.payload.JwtResponse;
import com.summer.summerapp.payload.LoginRequest;
import com.summer.summercore.dto.CategoryDTO;
import com.summer.summercore.dto.UserDetailsImpl;
import com.summer.summercore.entity.Category;
import com.summer.summercore.service.AuthService;
import com.summer.summercore.service.CategoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;


@RestController
@CrossOrigin
@RequestMapping(AppConstant.ROOT + AppConstant.CATEGORY)
public class CategoryApi {

    
    @Autowired
	private CategoryService categoryService;




    @GetMapping("/getallcategory")
    public ResponseEntity<CategoryDTO[]> getAllCategory(){
    	CategoryDTO[] result = null;
        HttpStatus status = HttpStatus.OK;
        try {
        	
            result = categoryService.findAllCategory().toArray(CategoryDTO[] ::new);
         
        } catch (Throwable e) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            e.printStackTrace();
        }
        return new ResponseEntity<>(result, status);
    }
}

