package com.summer.summerapp.constant;

public class AppConstant {

    public static final String ROOT = "/app/api";
    public static final String PRODUCT = "/product";
    public static final String LIST = "/list";
    public static final String CATEGORY = "/category" ;
    public static final String DELIVERY = "/delivery" ;
}
