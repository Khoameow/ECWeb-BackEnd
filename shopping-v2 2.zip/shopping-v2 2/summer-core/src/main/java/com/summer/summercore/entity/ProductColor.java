package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "PRODUCT_COLOR")
public class ProductColor extends BaseEntity {

    @Id
    @Column(value = "COLOR_ID")
    private Long colorId;

    @Column(value = "PRODUCT_ID")
    private Long productId;

    @Column(value = "COLOR_NAME")
    private String colorName;



}
