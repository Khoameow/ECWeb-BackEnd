package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "PRODUCT_PRICE")
public class Price extends BaseEntity{

    @Id
    @Column(value = "PRICE_ID")
    private Long priceId;

    @Column(value = "PRODUCT_ID")
    private Long productId;

    @Column(value = "PRICE_OUT")
    private Double priceOut;

    @Column(value = "IS_SALE")
    private Integer isSale;




}
