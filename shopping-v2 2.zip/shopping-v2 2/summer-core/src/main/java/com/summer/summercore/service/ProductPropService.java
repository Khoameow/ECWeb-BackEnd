package com.summer.summercore.service;

import com.summer.summercore.dto.ProductPropDTO;

import java.util.List;

public interface ProductPropService {

    List<ProductPropDTO> findAllProductProp();
}
