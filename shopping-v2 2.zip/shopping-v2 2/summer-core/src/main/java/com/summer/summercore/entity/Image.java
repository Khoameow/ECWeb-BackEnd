package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "PRODUCT_IMAGE")
public class Image extends BaseEntity{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @Column(value = "IMAGE_ID")
    private Long imageId;

    @Column(value = "IMAGE_NAME")
    private String imageName;

    @Column(value = "IMAGE_LINK")
    private String imageLink;

    @Column(value = "PRODUCT_ID")
    private Long productId;

    @Column(value = "IMAGE_TYPE")
    private Integer imageType;

    
}
