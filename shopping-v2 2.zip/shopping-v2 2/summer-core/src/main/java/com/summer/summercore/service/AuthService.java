package com.summer.summercore.service;

import com.summer.summercore.dto.AuthDTO;

public interface AuthService {
    AuthDTO findOneByUsername(String username);
    boolean usernameIsExist(String username);
    AuthDTO registry(AuthDTO authDto);
    AuthDTO save(AuthDTO authDto);
}
