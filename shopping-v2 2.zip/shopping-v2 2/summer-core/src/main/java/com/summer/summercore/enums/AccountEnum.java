package com.summer.summercore.enums;

public enum AccountEnum {
    ACCOUNT_ID,
    USERNAME,
    FULLNAME,
    EMAIL,
    GENDER
    ;
}
