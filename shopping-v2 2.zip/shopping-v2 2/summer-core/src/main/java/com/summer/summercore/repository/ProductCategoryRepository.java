package com.summer.summercore.repository;

import com.summer.summercore.dto.ProductCategoryDTO;
import com.summer.summercore.entity.ProductCategory;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductCategoryRepository extends PagingAndSortingRepository<ProductCategory,Long> {

    ProductCategory findOneById(Long id);

    ProductCategory findOneByProductId(Long productId);

    @Query("SELECT * FROM PRODUCT_CATEGORY WHERE PRODUCT_ID = :productId")
    List<ProductCategoryDTO> findAllByProductId(@Param("productId") Long productId);
}
