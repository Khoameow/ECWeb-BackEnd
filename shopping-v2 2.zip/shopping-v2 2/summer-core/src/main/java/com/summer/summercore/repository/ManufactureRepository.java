package com.summer.summercore.repository;

import java.util.List;

import com.summer.summercore.dto.ManufactureDTO;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;


import com.summer.summercore.entity.Category;
import com.summer.summercore.entity.Manufacture;

public interface ManufactureRepository extends PagingAndSortingRepository<Category,Long> {

	 @Query("SELECT * FROM MANUFACTURE")
	 List<ManufactureDTO> findAllManufacture();
	 
	 @Query("SELECT * FROM MANUFACTURE WHERE MANUFACTURE_ID IN  ( :manufactureIds)")
	 List<Manufacture> findAllManufactureByIds(@Param("manufactureIds") List<Integer> manufactureIds);
	 
	 @Query("select * from MANUFACTURE where MANUFACTURE_ID = :manufactureId;")
	 Manufacture getManufactureById(@Param("manufactureId") Long manufactureId);
}
