package com.summer.summercore.service;

import com.summer.summercore.dto.ProductColorDTO;

import java.util.List;

public interface ProductColorService {
    List<ProductColorDTO> findAllProductColor();
}
