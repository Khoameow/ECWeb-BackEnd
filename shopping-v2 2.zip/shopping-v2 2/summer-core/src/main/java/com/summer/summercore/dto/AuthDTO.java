package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthDTO {

    private Long authId;

    private Long accountId;

    private String username;

    private String password;

    private String type;
}
