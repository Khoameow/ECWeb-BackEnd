package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductColorDTO {

    private Long colorId;

    private Long productId;

    private String colorName;
}
