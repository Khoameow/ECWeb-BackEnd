package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "PRODUCT_STOCK")
public class Stock extends BaseEntity{

    @Id
    @Column(value = "STOCK_ID")
    private Long stockId;

    @Column(value = "PRODUCT_ID")
    private Long productId;

    @Column(value = "COLOR_ID")
    private Long colorId;

    @Column(value = "TOTAL")
    private Integer total;

    
}
