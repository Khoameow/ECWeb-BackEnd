package com.summer.summercore.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summercore.constant.CoreConstant;
import com.summer.summercore.dto.AccountDTO;
import com.summer.summercore.dto.ProductDTO;
import com.summer.summercore.entity.*;
import com.summer.summercore.enums.ProductEnum;
import com.summer.summercore.utils.CommonLogUtil;
import com.summer.summercore.utils.SecurityUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;

import com.summer.summercore.repository.ProductRepository;
import com.summer.summercore.service.ProductService;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

    Logger logger = (Logger) LoggerFactory.getLogger(ProductServiceImpl.class);

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    protected ObjectMapper objectMapper;


    @Override
    public List<ProductDTO> findAllProduct(int indexLimit , int indexOffset) {
        return productRepository.findAllProduct(indexLimit,indexOffset);
    }
    
    @Override
    public Product getProductById(Long productId) {
        return productRepository.getProductById(productId);
    }
    
    @Override
    public Product saveProduct(Product product) {
    	return productRepository.save(product);
    }
    @Override
    public boolean deleteProduct(long id) {
        try {
        	productRepository.deleteProductById(id);
        	return true;
        }catch (Exception e){
            return false;
        }
    }
    
    @Override
    public List<ProductDTO> findAllProductByCategoryId(Long categoryId, int indexLimit , int indexOffset) {
        return productRepository.findAllProductByCategoryId(categoryId, indexLimit, indexOffset);
    }
    
    @Override
    public List<Product> findAllProductTotal() {
        return productRepository.findAllProductTotal();
    }
    
    @Override
    public List<ProductCategory> findAllProductPresent() {
        return productRepository.findAllProductPresent();
    }
    
    @Override
    public List<Product> findAllProductByIds(List<Integer> productIds) {
        return productRepository.findAllProductByIds(productIds);
    }
    
    
    @Override
    public List<Image> getProductImageByIds(List<Integer> imageIds) {
        return productRepository.getProductImageByIds(imageIds);
    }
    
    @Override
    public List<Rating> findRatingbyProductId(Long productId) {
        return productRepository.findRatingbyProductId(productId);
    }
    
    @Override
    public List<Price> findPriceByProductId(Long productId) {
        return productRepository.findPriceByProductId(productId);
    }
    @Override
    public List<Stock> findStockByProductId(Long productId) {
        return productRepository.findStockByProductId(productId);
    }

    @Override
    public Long count() {
        return productRepository.countAllProduct();
    }





    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductDTO save(ProductDTO productDTO) {
        try {
            Product product = objectMapper.convertValue(productDTO, Product.class);
            Long id = product.getProductId();
            if(null != id){
                Product oldData = productRepository.findById(id).get();
                product.setCreatedBy(oldData.getCreatedBy());
                product.setCreatedDate(oldData.getCreatedDate());
                product.setUpdatedBy(SecurityUtil.getPrincipal().getUsername());
                product.setUpdatedDate(new Date(System.currentTimeMillis()));
            }
            else{
                product.setCreatedBy(SecurityUtil.getPrincipal().getUsername());
                product.setCreatedDate(new Date(System.currentTimeMillis()));
            }
            return objectMapper.convertValue(productRepository.save(product), ProductDTO.class);
        }catch (Exception e){
            CommonLogUtil.logError(e);
        }
        return null;
    }

    @Override
    public ProductDTO findOneById(Long id) {
        return productRepository.findOneByProductId(id);
    }
    @Override
    public List<Image> findImageByProductId(Long productId){
    	return productRepository.findImageByProductId(productId);
    }

	

}
