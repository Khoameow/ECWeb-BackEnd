package com.summer.summercore.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summercore.dto.AccountDTO;
import com.summer.summercore.dto.CartDTO;
import com.summer.summercore.dto.DeliveryDTO;
import com.summer.summercore.dto.ShippingDTO;
import com.summer.summercore.entity.Account;
import com.summer.summercore.entity.Auth;
import com.summer.summercore.entity.Delivery;
import com.summer.summercore.entity.DeliveryProduct;
import com.summer.summercore.entity.Image;
import com.summer.summercore.entity.Price;
import com.summer.summercore.entity.Product;
import com.summer.summercore.entity.Stock;
import com.summer.summercore.repository.AuthRepository;
import com.summer.summercore.repository.DeliveryProductRepository;
import com.summer.summercore.repository.DeliveryRepository;
import com.summer.summercore.repository.ProductRepository;
import com.summer.summercore.service.DeliveryService;
import com.summer.summercore.utils.CommonLogUtil;
import com.summer.summercore.utils.SecurityUtil;

@Service
public class DeliveryServiceImpl implements DeliveryService {

	Logger logger = (Logger) LoggerFactory.getLogger(DeliveryServiceImpl.class);

	@Autowired
	private DeliveryRepository deliveryRepository;

	@Autowired
	private DeliveryProductRepository deliveryProductRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private AuthRepository authRepository;

	@Autowired
	protected ObjectMapper objectMapper;

	/**
	 * handle input delivery
	 * 
	 * @param delivery
	 * @return
	 */
	@Override
	public int InsertDelivery(Delivery delivery) {
		return deliveryRepository.InsertDelivery(delivery.getCustomerName(), delivery.getPlaceDelivery(), 1,
				delivery.getDescription(), delivery.getAddress(), delivery.getAddressType(), delivery.getCity(),
				delivery.getCountry(), delivery.getLandmark(), delivery.getPhoneNumber(), delivery.getPinCode(),
				delivery.getItemsPrice(), delivery.getDiscountPrice(), delivery.getShippingPrice(),
				delivery.getTotalPrice());
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public Delivery Store(DeliveryDTO deliveryDTO) {
		try {

			Delivery deliveryStore = new Delivery();
			deliveryStore.setCustomerName(deliveryDTO.getShippingAddress().getName());
			;
			deliveryStore.setPlaceDelivery(deliveryDTO.getShippingAddress().getPlace());
			deliveryStore.setStatus(1);
			deliveryStore.setDescription("");
			deliveryStore.setAddress(deliveryDTO.getShippingAddress().getAddress());
			deliveryStore.setAddressType(deliveryDTO.getShippingAddress().getAddressType());
			deliveryStore.setCity(deliveryDTO.getShippingAddress().getCity());
			deliveryStore.setCountry(deliveryDTO.getShippingAddress().getCountry());
			deliveryStore.setLandmark(deliveryDTO.getShippingAddress().getLandmark());
			deliveryStore.setPhoneNumber(deliveryDTO.getShippingAddress().getMobile());
			deliveryStore.setPinCode(deliveryDTO.getShippingAddress().getPinCode());
			deliveryStore.setItemsPrice(deliveryDTO.getItemsPrice());
			deliveryStore.setDiscountPrice(deliveryDTO.getDiscountPrice());
			deliveryStore.setShippingPrice(deliveryDTO.getShippingPrice());
			deliveryStore.setTotalPrice(deliveryDTO.getTotalPrice());
			deliveryStore.setUserName(deliveryDTO.getUserName());
			deliveryStore.setDeleted(0);

			Auth auth = authRepository.findOneByUsername(deliveryDTO.getUserName());
			deliveryStore.setCreatedBy(auth.getUsername());
			deliveryStore.setCreatedDate(new Date(System.currentTimeMillis()));
			deliveryStore.setUpdatedBy(auth.getUsername());
			deliveryStore.setUpdatedDate(new Date(System.currentTimeMillis()));

			Delivery result = deliveryRepository.save(deliveryStore);
			int intCheck = 0;
			if (result != null) {

				if (deliveryDTO.getOrderItems() != null) {
					for (CartDTO item : deliveryDTO.getOrderItems()) {
						DeliveryProduct deliveryProduct = new DeliveryProduct();
						deliveryProduct.setDeliveryId(result.getDeliveryId());
						deliveryProduct.setProductId(item.getProduct());
						deliveryProduct.setQuanlity(Integer.parseInt(item.getQty()));
						deliveryProduct.setDeleted(0);
						deliveryProduct.setCreatedBy(auth.getUsername());
						deliveryProduct.setCreatedDate(new Date(System.currentTimeMillis()));
						deliveryProduct.setUpdatedBy(auth.getUsername());
						deliveryProduct.setUpdatedDate(new Date(System.currentTimeMillis()));
						DeliveryProduct resultDeliveryProduct = deliveryProductRepository.save(deliveryProduct);
						if (resultDeliveryProduct != null) {
							intCheck++;
						}
					}
				}

			}
			if (intCheck > 0) {
				return result;
			}
		} catch (Exception e) {
			CommonLogUtil.logError(e);
		}
		return null;
	}

	public DeliveryDTO getDeliverybyIds(Long deliveryId) {
		DeliveryDTO deliveryDTO = new DeliveryDTO();
		List<CartDTO> cartDTOs = new ArrayList<>();
		deliveryDTO.setOrderItems(null);
		Delivery delivery = deliveryRepository.findOneByDeliveryId(deliveryId);
		List<DeliveryProduct> deliveryProducts = deliveryProductRepository.getDeliveryProductByDeliveryId(deliveryId);
		for (DeliveryProduct item : deliveryProducts) {
			CartDTO cartDTO = new CartDTO();
			Product product = productRepository.getProductById(item.getProductId());

			cartDTO.setProduct(product.getProductId());
			List<Image> lstImage = productRepository.findImageByProductId(product.getProductId());
			if (lstImage.size() > 0) {
				cartDTO.setImagePresent(lstImage.get(0).getImageLink());
			}

			List<Price> lstPrice = productRepository.findPriceByProductId(product.getProductId());
			if (lstPrice.size() > 0) {
				cartDTO.setPriceValue(lstPrice.get(0).getPriceOut());
			}

			cartDTO.setProductName(product.getProductName());

			List<Stock> lstStock = productRepository.findStockByProductId(product.getProductId());
			if (lstStock.size() > 0) {
				cartDTO.setStockTotal(lstStock.get(0).getTotal());
			}

			cartDTO.setQty(String.valueOf(item.getQuanlity()));
			cartDTOs.add(cartDTO);
		}
		deliveryDTO.setCartItems(cartDTOs.toArray(CartDTO[]::new));
		ShippingDTO shippingDTO = new ShippingDTO();
		shippingDTO.setAddress(delivery.getAddress());
		shippingDTO.setAddressType(delivery.getAddressType());
		shippingDTO.setCity(delivery.getCity());
		shippingDTO.setCountry(delivery.getCountry());
		shippingDTO.setLandmark(delivery.getLandmark());
		shippingDTO.setMobile(delivery.getPhoneNumber());
		shippingDTO.setName(delivery.getCustomerName());
		shippingDTO.setPinCode(delivery.getPinCode());
		shippingDTO.setPlace(delivery.getPlaceDelivery());
		deliveryDTO.setShippingAddress(shippingDTO);
		deliveryDTO.setOrderItems(cartDTOs.toArray(CartDTO[]::new));
		deliveryDTO.setDiscountPrice(delivery.getDiscountPrice());
		deliveryDTO.setItemsPrice(delivery.getItemsPrice());
		deliveryDTO.setShippingPrice(delivery.getShippingPrice());
		deliveryDTO.setTotalPrice(delivery.getTotalPrice());
		deliveryDTO.setCreateDate(delivery.getCreatedDate());
		return deliveryDTO;
	}

	public List<DeliveryDTO> getDeliverybyUserName(String userName) {
		List<DeliveryDTO> deliveryDTOs = new ArrayList<>();
		List<Delivery> deliverys = deliveryRepository.findAllByUserName(userName);
		for (Delivery delivery : deliverys) {
			DeliveryDTO deliveryDTO = new DeliveryDTO();
			List<CartDTO> cartDTOs = new ArrayList<>();
			deliveryDTO.setOrderItems(null);
			List<DeliveryProduct> deliveryProducts = deliveryProductRepository
					.getDeliveryProductByDeliveryId(delivery.getDeliveryId());
			for (DeliveryProduct item : deliveryProducts) {
				CartDTO cartDTO = new CartDTO();
				Product product = productRepository.getProductById(item.getProductId());

				cartDTO.setProduct(product.getProductId());
				List<Image> lstImage = productRepository.findImageByProductId(product.getProductId());
				if (lstImage.size() > 0) {
					cartDTO.setImagePresent(lstImage.get(0).getImageLink());
				}

				List<Price> lstPrice = productRepository.findPriceByProductId(product.getProductId());
				if (lstPrice.size() > 0) {
					cartDTO.setPriceValue(lstPrice.get(0).getPriceOut());
				}

				cartDTO.setProductName(product.getProductName());

				List<Stock> lstStock = productRepository.findStockByProductId(product.getProductId());
				if (lstStock.size() > 0) {
					cartDTO.setStockTotal(lstStock.get(0).getTotal());
				}

				cartDTO.setQty(String.valueOf(item.getQuanlity()));
				cartDTO.setCreatedDate(item.getCreatedDate());
				cartDTOs.add(cartDTO);
			}
			deliveryDTO.setCartItems(cartDTOs.toArray(CartDTO[]::new));
			ShippingDTO shippingDTO = new ShippingDTO();
			shippingDTO.setAddress(delivery.getAddress());
			shippingDTO.setAddressType(delivery.getAddressType());
			shippingDTO.setCity(delivery.getCity());
			shippingDTO.setCountry(delivery.getCountry());
			shippingDTO.setLandmark(delivery.getLandmark());
			shippingDTO.setMobile(delivery.getPhoneNumber());
			shippingDTO.setName(delivery.getCustomerName());
			shippingDTO.setPinCode(delivery.getPinCode());
			shippingDTO.setPlace(delivery.getPlaceDelivery());
			deliveryDTO.setShippingAddress(shippingDTO);
			deliveryDTO.setOrderItems(cartDTOs.toArray(CartDTO[]::new));
			deliveryDTO.setDiscountPrice(delivery.getDiscountPrice());
			deliveryDTO.setItemsPrice(delivery.getItemsPrice());
			deliveryDTO.setShippingPrice(delivery.getShippingPrice());
			deliveryDTO.setTotalPrice(delivery.getTotalPrice());
			deliveryDTO.setDeliveryId(delivery.getDeliveryId());
			deliveryDTO.setCreateDate(delivery.getCreatedDate());
			deliveryDTO.setStatus(delivery.getStatus());

			deliveryDTOs.add(deliveryDTO);
		}
		return deliveryDTOs;
	}

	public List<DeliveryDTO> getAllDelivery() {
		List<DeliveryDTO> deliveryDTOs = new ArrayList<>();
		List<Delivery> deliverys = (List<Delivery>) deliveryRepository.findAll();
		for (Delivery delivery : deliverys) {
			DeliveryDTO deliveryDTO = new DeliveryDTO();
			List<CartDTO> cartDTOs = new ArrayList<>();
			deliveryDTO.setOrderItems(null);
			List<DeliveryProduct> deliveryProducts = deliveryProductRepository
					.getDeliveryProductByDeliveryId(delivery.getDeliveryId());
			for (DeliveryProduct item : deliveryProducts) {
				CartDTO cartDTO = new CartDTO();
				Product product = productRepository.getProductById(item.getProductId());

				cartDTO.setProduct(product.getProductId());
				List<Image> lstImage = productRepository.findImageByProductId(product.getProductId());
				if (lstImage.size() > 0) {
					cartDTO.setImagePresent(lstImage.get(0).getImageLink());
				}

				List<Price> lstPrice = productRepository.findPriceByProductId(product.getProductId());
				if (lstPrice.size() > 0) {
					cartDTO.setPriceValue(lstPrice.get(0).getPriceOut());
				}

				cartDTO.setProductName(product.getProductName());

				List<Stock> lstStock = productRepository.findStockByProductId(product.getProductId());
				if (lstStock.size() > 0) {
					cartDTO.setStockTotal(lstStock.get(0).getTotal());
				}

				cartDTO.setQty(String.valueOf(item.getQuanlity()));
				cartDTO.setCreatedDate(item.getCreatedDate());
				cartDTOs.add(cartDTO);
			}
			deliveryDTO.setCartItems(cartDTOs.toArray(CartDTO[]::new));
			ShippingDTO shippingDTO = new ShippingDTO();
			shippingDTO.setAddress(delivery.getAddress());
			shippingDTO.setAddressType(delivery.getAddressType());
			shippingDTO.setCity(delivery.getCity());
			shippingDTO.setCountry(delivery.getCountry());
			shippingDTO.setLandmark(delivery.getLandmark());
			shippingDTO.setMobile(delivery.getPhoneNumber());
			shippingDTO.setName(delivery.getCustomerName());
			shippingDTO.setPinCode(delivery.getPinCode());
			shippingDTO.setPlace(delivery.getPlaceDelivery());
			deliveryDTO.setShippingAddress(shippingDTO);
			deliveryDTO.setOrderItems(cartDTOs.toArray(CartDTO[]::new));
			deliveryDTO.setDiscountPrice(delivery.getDiscountPrice());
			deliveryDTO.setItemsPrice(delivery.getItemsPrice());
			deliveryDTO.setShippingPrice(delivery.getShippingPrice());
			deliveryDTO.setTotalPrice(delivery.getTotalPrice());
			deliveryDTO.setDeliveryId(delivery.getDeliveryId());
			deliveryDTO.setCreateDate(delivery.getCreatedDate());
			deliveryDTO.setStatus(delivery.getStatus());

			deliveryDTOs.add(deliveryDTO);
		}
		return deliveryDTOs;
	}

	@Override
	public DeliveryDTO findOneByDeliveryId(Long id) {
		return objectMapper.convertValue(deliveryRepository.findOneByDeliveryId(id), DeliveryDTO.class);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public DeliveryDTO updateStatus(DeliveryDTO deliveryDTO) {
		try {
			Delivery delivery = deliveryRepository.findOneByDeliveryId(deliveryDTO.getDeliveryId());
			delivery.setStatus(deliveryDTO.getStatus());
			deliveryRepository.save(delivery);
			return objectMapper.convertValue(deliveryRepository.save(delivery), DeliveryDTO.class);
		} catch (Exception e) {
			CommonLogUtil.logError(e);
		}
		return null;
	}
}
