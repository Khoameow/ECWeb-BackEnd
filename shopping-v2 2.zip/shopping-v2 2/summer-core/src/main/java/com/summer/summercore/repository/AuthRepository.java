package com.summer.summercore.repository;

import com.summer.summercore.entity.Auth;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface AuthRepository extends PagingAndSortingRepository<Auth,Long> {
    Auth findOneByUsername(String username);

    Auth findOneByAuthId(Long authId);

    @Modifying
    @Query("UPDATE AUTH auth SET auth.DELETED = 1 WHERE auth.ACCOUNT_ID = :id")
    void deleteAuth(Long id);

    Auth findOneByAccountId(Long accountId);
}
