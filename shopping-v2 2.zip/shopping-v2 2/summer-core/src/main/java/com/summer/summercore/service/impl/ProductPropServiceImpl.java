package com.summer.summercore.service.impl;

import com.summer.summercore.dto.ProductPropDTO;
import com.summer.summercore.repository.ProductPropRepository;
import com.summer.summercore.service.ProductPropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductPropServiceImpl implements ProductPropService {

    @Autowired
    private ProductPropRepository productPropRepository;

    @Override
    public List<ProductPropDTO> findAllProductProp() {
        return productPropRepository.findAllProductProp();
    }
}
