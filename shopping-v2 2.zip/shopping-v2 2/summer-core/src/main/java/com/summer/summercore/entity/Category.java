package com.summer.summercore.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;
@Getter
@Setter
@Table(name = "CATEGORY")
public class Category extends BaseEntity{

    @Id
    @Column(value = "CATEGORY_ID")
    private Long categoryId;

    @Column(value = "CATEGORY_NAME")
    private String categoryName;
    
    @Column(value = "CATEGORY_IMAGE")
    private String categoryImage;

	
}
