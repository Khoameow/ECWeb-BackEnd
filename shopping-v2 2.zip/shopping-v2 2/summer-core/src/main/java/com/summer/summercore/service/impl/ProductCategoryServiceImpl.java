package com.summer.summercore.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summercore.dto.ProductCategoryDTO;
import com.summer.summercore.dto.ProductDTO;
import com.summer.summercore.entity.Product;
import com.summer.summercore.entity.ProductCategory;
import com.summer.summercore.repository.ProductCategoryRepository;
import com.summer.summercore.service.ProductCategoryService;
import com.summer.summercore.utils.CommonLogUtil;
import com.summer.summercore.utils.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {

    @Autowired
    private ProductCategoryRepository productCategoryRepository;

    @Autowired
    protected ObjectMapper objectMapper;


    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductCategoryDTO save(ProductCategoryDTO dto) {
        try {
            ProductCategory entity = objectMapper.convertValue(dto, ProductCategory.class);
            Long id = entity.getId();
            if(null != id){
                ProductCategory oldData = productCategoryRepository.findOneById(id);
                entity.setCreatedBy(oldData.getCreatedBy());
                entity.setCreatedDate(oldData.getCreatedDate());
                entity.setUpdatedBy(SecurityUtil.getPrincipal().getUsername());
                entity.setUpdatedDate(new Date(System.currentTimeMillis()));
            }
            else{
                entity.setCreatedBy(SecurityUtil.getPrincipal().getUsername());
                entity.setCreatedDate(new Date(System.currentTimeMillis()));
            }
            return objectMapper.convertValue(productCategoryRepository.save(entity), ProductCategoryDTO.class);
        }catch (Exception e){
            CommonLogUtil.logError(e);
        }
        return null;
    }

    @Override
    public List<ProductCategoryDTO> findAllByProductId(Long productId) {
        return productCategoryRepository.findAllByProductId(productId);
    }


}
