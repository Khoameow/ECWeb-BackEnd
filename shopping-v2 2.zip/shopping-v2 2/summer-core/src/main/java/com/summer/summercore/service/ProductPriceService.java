package com.summer.summercore.service;

import com.summer.summercore.dto.PriceDTO;
import com.summer.summercore.dto.ProductDTO;

public interface ProductPriceService {

    PriceDTO save(PriceDTO priceDto);

    PriceDTO findOneByPriceId(Long priceId);

    PriceDTO findOneByProductId(Long productId);
}
