package com.summer.summercore.service.impl;

import com.summer.summercore.dto.ProductColorDTO;
import com.summer.summercore.repository.ProductColorRepository;
import com.summer.summercore.service.ProductColorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductColorServiceImpl implements ProductColorService {

    @Autowired
    private ProductColorRepository productColorRepository;


    @Override
    public List<ProductColorDTO> findAllProductColor() {
        return productColorRepository.findAllProductColor();
    }
}
