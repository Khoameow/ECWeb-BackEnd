package com.summer.summercore.repository;

import com.summer.summercore.entity.Price;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ProductPriceRepository extends PagingAndSortingRepository<Price, Long> {


    Price findOneByPriceId(Long priceId);

    Price findOneByProductId(Long productId);
}
