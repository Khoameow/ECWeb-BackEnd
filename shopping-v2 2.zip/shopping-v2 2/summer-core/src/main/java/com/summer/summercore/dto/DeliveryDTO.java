package com.summer.summercore.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeliveryDTO {
	private Long deliveryId;
	private CartDTO[] cartItems;
	private Double discountPrice;
	private Double itemsPrice;
	private CartDTO[] orderItems;
	private String paymentMethod;
	private ShippingDTO shippingAddress;
	private Double shippingPrice;
	private Double totalPrice;
	private String userName;
	private Date createDate;
	private int status;
}
