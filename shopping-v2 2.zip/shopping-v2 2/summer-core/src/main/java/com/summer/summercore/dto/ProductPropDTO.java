package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductPropDTO {
    private Long propId;

    private String propName;
}
