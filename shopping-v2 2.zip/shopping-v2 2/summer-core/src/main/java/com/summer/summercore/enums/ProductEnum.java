package com.summer.summercore.enums;

public enum ProductEnum {
    ID
}
