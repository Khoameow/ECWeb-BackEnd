package com.summer.summercore.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summercore.constant.CoreConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class BaseService {


    //    private JdbcTemplate jdbcTemplate;

    @Autowired
    protected NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    protected ObjectMapper objectMapper;


    protected String buildSortAndPaging(Pageable pageable, Enum[] enumsData) {
        String sortName;
        String sortBy;
        Long pageIndex;
        Integer pageSize;
        StringBuilder sortAndPagingQuery = new StringBuilder("ORDER BY ");

        //Build Sort
//        if(!pageable.getSort().isSorted()){
//            sortAndPagingQuery.append("ID ASC ");
//        }
//        else {
//            for(Sort.Order order : pageable.getSort()){
//                sortName = order.isAscending() ? Sort.Direction.ASC.name() : Sort.Direction.DESC.name();
//                sortBy = Stream.of(enumsData).filter(p->p.name().equals(order.getProperty().toUpperCase()))
//                        .map(Enum::name).findFirst()
//                        .orElse("ID");
//                sortAndPagingQuery.append(sortBy + CoreConstant.SPACE);
//                sortAndPagingQuery.append(sortName + CoreConstant.SPACE);
//                break;
//            }
//        }

        sortAndPagingQuery.append(" ACCOUNT_ID DESC ");

        //Build Paging
        pageIndex = pageable.getOffset();
        pageSize = pageable.getPageSize();

        if(null != pageIndex && null != pageSize){
            sortAndPagingQuery.append("LIMIT " + pageSize + " OFFSET " + pageIndex + CoreConstant.SPACE);
        }
        return sortAndPagingQuery.toString();
    }


    protected void bindQueryForLogging(String query, MapSqlParameterSource mapSqlParameterSource){
        String sql = query;
        for(String item:mapSqlParameterSource.getParameterNames()){
            String parameter = item;
            String value = "";
            Object object = mapSqlParameterSource.getValue(item);
            if(object instanceof Long || object instanceof Integer){
                value = " " + object.toString() + " ";
            }
            else{
                value = " " + "'" + mapSqlParameterSource.getValue(item).toString() + "'" + " ";
            }

            sql = sql.replace(":".concat(parameter),value);
        }
        System.out.println(sql);
    }

}
