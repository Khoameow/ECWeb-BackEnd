package com.summer.summercore.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "PRODUCT_PROP")
public class ProductProp {


    @Id
    @Column(value = "PROP_ID")
    private Long propId;

    @Column(value = "PROP_NAME")
    private String propName;
}
