package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShippingDTO {

	private String address;
	
	private String addressType;
	
	private String city;
	
	private String country;

	private String landmark;

	private String mobile;

	private String name;

	private String pinCode;

	private String place;

}
