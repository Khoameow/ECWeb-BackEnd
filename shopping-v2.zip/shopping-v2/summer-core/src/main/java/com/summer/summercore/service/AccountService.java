package com.summer.summercore.service;

import com.summer.summercore.dto.AccountDTO;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AccountService {
    List<AccountDTO> search(String keySearch, Pageable pageable);
    long count();
    AccountDTO save(AccountDTO accountDto);
    AccountDTO findOneByUsername(String username);
    AccountDTO findOneById(Long id);
    void deleteAccount(List<Long> ids);
}
