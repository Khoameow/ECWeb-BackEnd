//package com.summer.summercore.dto;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Getter
//@Setter
//public class BaseDto {
//    private String keySearch;
//}
