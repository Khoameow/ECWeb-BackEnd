package com.summer.summercore.constant;

public class CoreConstant {
    public static final String SPACE = " ";
    public static final String EMPTY = "";

    public static final String SUCCESS = "SUCCESS";
    public static final String FIND_ALL_PRODUCT = "SELECT\n" +
            "    product.PRODUCT_ID AS PRODUCT_ID,\n" +
            "    product.PRODUCT_NAME AS PRODUCT_NAME,\n" +
            "    product.PRODUCT_CODE AS PRODUCT_CODE,\n" +
            "    product.LIST_COLOR AS LIST_COLOR,\n" +
            "    product.LIST_PROP AS LIST_PROP,\n" +
            "    price.PRICE_OUT AS PRICE_VALUE,\n" +
            "    price.PRICE_ID  AS PRICE_ID,\n" +
            "    manufacture.MANUFACTURE_NAME AS MANUFACTURE_NAME,\n" +
            "    manufacture.MANUFACTURE_ID AS MANUFACTURE_ID,\n" +
            "    category.CATEGORY_NAME AS CATEGORY_NAME,\n" +
            "    category.CATEGORY_ID   AS CATEGORY_ID\n" +
            "FROM\n" +
            "    PRODUCT product\n" +
            "LEFT JOIN\n" +
            "    PRODUCT_PRICE price\n" +
            "ON\n" +
            "    price.PRODUCT_ID = product.PRODUCT_ID\n" +
            "LEFT JOIN\n" +
            "    MANUFACTURE manufacture\n" +
            "ON\n" +
            "    manufacture.MANUFACTURE_ID = product.MANUFACTURE_ID\n" +
            "LEFT JOIN\n" +
            "    PRODUCT_CATEGORY pc\n" +
            "ON\n" +
            "    pc.PRODUCT_ID = product.PRODUCT_ID\n" +
            "LEFT JOIN\n" +
            "    CATEGORY category\n" +
            "ON\n" +
            "    category.CATEGORY_ID = pc.CATEGORY_ID\n" +
            " WHERE product.DELETED = 0 " +
            "ORDER BY product.PRODUCT_ID DESC limit :indexLimit OFFSET :indexOffset";


    public static final String FIND_ONE_PRODUCT = "SELECT\n" +
            "    product.PRODUCT_ID AS PRODUCT_ID,\n" +
            "    product.PRODUCT_NAME AS PRODUCT_NAME,\n" +
            "    product.PRODUCT_CODE AS PRODUCT_CODE,\n" +
            "    product.LIST_COLOR AS LIST_COLOR,\n" +
            "    product.LIST_PROP AS LIST_PROP,\n" +
            "    price.PRICE_OUT AS PRICE_VALUE,\n" +
            "    price.PRICE_ID  AS PRICE_ID,\n" +
            "    manufacture.MANUFACTURE_NAME AS MANUFACTURE_NAME,\n" +
            "    manufacture.MANUFACTURE_ID AS MANUFACTURE_ID,\n" +
            "    category.CATEGORY_NAME AS CATEGORY_NAME,\n" +
            "    category.CATEGORY_ID   AS CATEGORY_ID\n" +
            "FROM\n" +
            "    PRODUCT product\n" +
            "LEFT JOIN\n" +
            "    PRODUCT_PRICE price\n" +
            "ON\n" +
            "    price.PRODUCT_ID = product.PRODUCT_ID\n" +
            "LEFT JOIN\n" +
            "    MANUFACTURE manufacture\n" +
            "ON\n" +
            "    manufacture.MANUFACTURE_ID = product.MANUFACTURE_ID\n" +
            "LEFT JOIN\n" +
            "    PRODUCT_CATEGORY pc\n" +
            "ON\n" +
            "    pc.PRODUCT_ID = product.PRODUCT_ID\n" +
            "LEFT JOIN\n" +
            "    CATEGORY category\n" +
            "ON\n" +
            "    category.CATEGORY_ID = pc.CATEGORY_ID\n" +
            "WHERE product.PRODUCT_ID = :productId AND product.DELETED = 0";

    public static final String FIND_ALL_ACCOUNT = "SELECT\n" +
            "       account.ACCOUNT_ID,\n" +
            "       account.USERNAME,\n" +
            "       account.EMAIL,\n" +
            "       account.FULLNAME,\n" +
            "       account.GENDER\n" +
            "FROM\n" +
            "    ACCOUNT account\n" +
            "LEFT JOIN\n" +
            "    AUTH auth\n" +
            "ON account.ACCOUNT_ID = auth.ACCOUNT_ID\n" +
            "WHERE account.DELETED = 0 AND auth.DELETED = 0\n" +
            "ORDER BY account.ACCOUNT_ID DESC LIMIT :indexLimit OFFSET :indexOffset";
    
    public static final String FIND_ALL_PRODUCT_BY_CATEGORY= "SELECT\n" +
            "    product.PRODUCT_ID AS PRODUCT_ID,\n" +
            "    product.PRODUCT_NAME AS PRODUCT_NAME,\n" +
            "    product.PRODUCT_CODE AS PRODUCT_CODE,\n" +
            "    product.LIST_COLOR AS LIST_COLOR,\n" +
            "    product.LIST_PROP AS LIST_PROP,\n" +
            "    price.PRICE_OUT AS PRICE_VALUE,\n" +
            "    price.PRICE_ID  AS PRICE_ID,\n" +
            "    manufacture.MANUFACTURE_NAME AS MANUFACTURE_NAME,\n" +
            "    manufacture.MANUFACTURE_ID AS MANUFACTURE_ID,\n" +
            "    category.CATEGORY_NAME AS CATEGORY_NAME,\n" +
            "    category.CATEGORY_ID   AS CATEGORY_ID\n" +
            "FROM\n" +
            "    PRODUCT product\n" +
            "LEFT JOIN\n" +
            "    PRODUCT_PRICE price\n" +
            "ON\n" +
            "    price.PRODUCT_ID = product.PRODUCT_ID\n" +
            "LEFT JOIN\n" +
            "    MANUFACTURE manufacture\n" +
            "ON\n" +
            "    manufacture.MANUFACTURE_ID = product.MANUFACTURE_ID\n" +
            "LEFT JOIN\n" +
            "    PRODUCT_CATEGORY pc\n" +
            "ON\n" +
            "    pc.PRODUCT_ID = product.PRODUCT_ID\n" +
            "LEFT JOIN\n" +
            "    CATEGORY category\n" +
            "ON\n" +
            "    category.CATEGORY_ID = pc.CATEGORY_ID\n" +
            "WHERE category.CATEGORY_ID = :categoryId" +
            " AND product.DELETED = 0 " +
            "ORDER BY product.PRODUCT_ID DESC limit :indexLimit OFFSET :indexOffset";
}
