package com.summer.summercore.repository;

import com.summer.summercore.entity.Stock;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface StockRepository extends PagingAndSortingRepository<Stock,Long> {

}
