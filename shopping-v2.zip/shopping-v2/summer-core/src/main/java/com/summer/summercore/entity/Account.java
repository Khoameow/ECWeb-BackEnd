package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "ACCOUNT")
public class Account extends BaseEntity {

    @Id
    @Column(value = "ACCOUNT_ID")
    private Long accountId;

    @Column(value = "USERNAME")
    private String username;

    @Column(value = "FULLNAME")
    private String fullname;

    @Column(value = "EMAIL")
    private String email;

    @Column(value = "GENDER")
    private String gender;

}
