package com.summer.summercore.service;

import com.summer.summercore.dto.ManufactureDTO;
import com.summer.summercore.entity.Manufacture;

import java.util.List;

public interface ManufactureService {

	List<ManufactureDTO> findAllManufacture();
	List<Manufacture> findAllManufactureByIds(List<Integer> manufactureIds);
	Manufacture getManufactureById(Long manufactureId);
}
