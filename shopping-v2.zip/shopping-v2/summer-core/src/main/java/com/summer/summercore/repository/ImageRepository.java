package com.summer.summercore.repository;

import com.summer.summercore.entity.Image;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ImageRepository extends PagingAndSortingRepository<Image,Long> {

    Image findOneByProductId(Long productId);
}
