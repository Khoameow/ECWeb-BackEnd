package com.summer.summercore.service.impl;

import com.summer.summercore.dto.AuthDTO;
import com.summer.summercore.entity.Auth;
import com.summer.summercore.repository.AuthRepository;
import com.summer.summercore.service.AuthService;
import com.summer.summercore.utils.CommonLogUtil;
import com.summer.summercore.utils.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Objects;

@Service
public class AuthServiceImpl extends BaseService implements AuthService {

    @Autowired
    private AuthRepository authRepository;

    @Override
    public AuthDTO findOneByUsername(String username) {
        Auth auth = authRepository.findOneByUsername(username);
        return objectMapper.convertValue(auth, AuthDTO.class);
    }

    @Override
    public boolean usernameIsExist(String username) {
        return Objects.nonNull(authRepository.findOneByUsername(username)) ? true : false;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public AuthDTO registry(AuthDTO authDto) {
        authDto.setType("BASIC_AUTHEN");
        Auth auth = authRepository.save(objectMapper.convertValue(authDto, Auth.class));
        return objectMapper.convertValue(auth, AuthDTO.class);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public AuthDTO save(AuthDTO authDto) {
        try {
            Auth auth = objectMapper.convertValue(authDto, Auth.class);
            Long id = auth.getAuthId();
            if(null != id){
                Auth authDb = authRepository.findOneByAuthId(id);
                auth.setCreatedBy(authDb.getCreatedBy());
                auth.setCreatedDate(authDb.getCreatedDate());
                auth.setUpdatedBy(SecurityUtil.getPrincipal().getUsername());
                auth.setUpdatedDate(new Date(System.currentTimeMillis()));
            }
            else{
                auth.setCreatedBy(SecurityUtil.getPrincipal().getUsername());
                auth.setCreatedDate(new Date(System.currentTimeMillis()));
            }
            return objectMapper.convertValue(authRepository.save(auth), AuthDTO.class);
        }catch (Exception e){
            CommonLogUtil.logError(e);
        }
        return null;
    }
}
