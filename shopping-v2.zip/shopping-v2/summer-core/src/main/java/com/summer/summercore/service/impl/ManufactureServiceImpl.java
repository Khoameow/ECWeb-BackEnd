package com.summer.summercore.service.impl;

import java.util.List;

import com.summer.summercore.dto.ManufactureDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.summer.summercore.entity.Manufacture;
import com.summer.summercore.repository.ManufactureRepository;
import com.summer.summercore.service.ManufactureService;



@Service
public class ManufactureServiceImpl implements ManufactureService {

    Logger logger = (Logger) LoggerFactory.getLogger(ManufactureServiceImpl.class);

    @Autowired
    private ManufactureRepository manufactureRepository;


    @Override
    public List<ManufactureDTO> findAllManufacture() {
        return manufactureRepository.findAllManufacture();
    }
    
    @Override
    public List<Manufacture> findAllManufactureByIds(List<Integer> manufactureIds) {
        return manufactureRepository.findAllManufactureByIds(manufactureIds);
    }

    
    @Override
    public Manufacture getManufactureById(Long manufactureId) {
        return manufactureRepository.getManufactureById(manufactureId);
    }
}
