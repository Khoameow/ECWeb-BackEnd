package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountDTO {

    private Long accountId;

    private String username;

    private String fullname;

    private String email;

    private String gender;

    private String password;
}
