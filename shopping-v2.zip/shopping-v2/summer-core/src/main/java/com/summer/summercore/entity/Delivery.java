package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "DELIVERY")
public class Delivery extends BaseEntity{

    @Id
    @Column(value = "DELIVERY_ID")
    private Long deliveryId;

    @Column(value = "CUSTOMER_NAME")
    private String customerName;
    
    @Column(value = "PLACE_DELIVERY")
    private String placeDelivery;

    @Column(value = "STATUS")
    private Integer status;
    
    @Column(value = "DESCRIPTION")
    private String description;
    
    @Column(value = "ADDRESS")
    private String address;
    
    @Column(value = "ADDRESS_TYPE")
    private String addressType;
    
    @Column(value = "CITY")
    private String city;
    
    @Column(value = "COUNTRY")
    private String country;
    
    @Column(value = "LANDMARK")
    private String landmark;
    
    @Column(value = "PHONE_NUMBER")
    private String phoneNumber;
    
    @Column(value = "PIN_CODE")
    private String pinCode;
    
    @Column(value = "ITEMS_PRICE")
    private Double itemsPrice;
    
    @Column(value = "DISCOUNT_PRICE")
    private Double discountPrice;
    
    @Column(value = "SHIPPING_PRICE")
    private Double shippingPrice;
    
    @Column(value = "TOTAL_PRICE")
    private Double totalPrice;
    
    @Column(value = "USERNAME")
    private String userName;
}
