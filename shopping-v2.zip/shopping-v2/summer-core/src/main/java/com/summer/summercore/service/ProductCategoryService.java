package com.summer.summercore.service;

import com.summer.summercore.dto.ProductCategoryDTO;

import java.util.List;

public interface ProductCategoryService {
    ProductCategoryDTO save(ProductCategoryDTO dto);


    List<ProductCategoryDTO> findAllByProductId(Long productId);
}
