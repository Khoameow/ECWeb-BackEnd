package com.summer.summercore.repository;

import com.summer.summercore.dto.ProductColorDTO;
import com.summer.summercore.entity.ProductColor;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface ProductColorRepository extends PagingAndSortingRepository<ProductColor, Long> {

    @Query("SELECT * FROM PRODUCT_COLOR")
    List<ProductColorDTO> findAllProductColor();
}
