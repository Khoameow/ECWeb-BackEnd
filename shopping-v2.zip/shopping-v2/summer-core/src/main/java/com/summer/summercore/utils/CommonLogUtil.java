package com.summer.summercore.utils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonLogUtil {

    public static void logError(Exception e) {
        e.printStackTrace();
    }
}
