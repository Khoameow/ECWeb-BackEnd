package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDTO {

	private Long productId;

	private String productName;

	private String productCode;

	private String listColor;

	private Long priceId;

	private String listProp;

	private Long rateId;

	private Long manufactureId;

	private Long countryId;

	private String decription;

	private String imagePresent;

	private String imageLink;

	private String price;
	
	private int ratingValue;
	
	private Double priceValue;
	
	private int stockTotal;
	
	private String manufactureName;

	private String listImage;

	private Long categoryId;

}
