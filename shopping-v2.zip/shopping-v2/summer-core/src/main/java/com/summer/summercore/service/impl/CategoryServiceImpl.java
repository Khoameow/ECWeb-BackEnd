package com.summer.summercore.service.impl;

import java.util.List;

import com.summer.summercore.dto.CategoryDTO;
import com.summer.summercore.service.CategoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.summer.summercore.entity.Category;
import com.summer.summercore.repository.CategoryRepository;



@Service
public class CategoryServiceImpl implements CategoryService {

    Logger logger = (Logger) LoggerFactory.getLogger(CategoryServiceImpl.class);

    @Autowired
    private CategoryRepository categoryRepository;


    @Override
    public List<CategoryDTO> findAllCategory() {
        return categoryRepository.findAllCategory();
    }
    
    @Override
    public List<Category> findAllCategoryByIds(List<Integer> categoryIds) {
        return categoryRepository.findAllCategoryByIds(categoryIds);
    }

    
    @Override
    public Category getCategoryById(Long categoryId) {
        return categoryRepository.getCategoryById(categoryId);
    }
}
