package com.summer.summercore.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summercore.dto.PriceDTO;
import com.summer.summercore.dto.ProductDTO;
import com.summer.summercore.entity.Price;
import com.summer.summercore.entity.Product;
import com.summer.summercore.repository.ProductPriceRepository;
import com.summer.summercore.service.ProductPriceService;
import com.summer.summercore.utils.CommonLogUtil;
import com.summer.summercore.utils.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class ProductPriceServiceImpl implements ProductPriceService {

    @Autowired
    protected ObjectMapper objectMapper;

    @Autowired
    private ProductPriceRepository priceRepository;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public PriceDTO save(PriceDTO priceDto) {
        try {
            Price price = objectMapper.convertValue(priceDto, Price.class);
            Long id = price.getPriceId();
            if(null != id){
                Price oldData = priceRepository.findOneByPriceId(id);
                price.setCreatedBy(oldData.getCreatedBy());
                price.setCreatedDate(oldData.getCreatedDate());
                price.setUpdatedBy(SecurityUtil.getPrincipal().getUsername());
                price.setUpdatedDate(new Date(System.currentTimeMillis()));
            }
            else{
                price.setCreatedBy(SecurityUtil.getPrincipal().getUsername());
                price.setCreatedDate(new Date(System.currentTimeMillis()));
            }
            return objectMapper.convertValue(priceRepository.save(price), PriceDTO.class);
        }catch (Exception e){
            CommonLogUtil.logError(e);
        }
        return null;
    }

    @Override
    public PriceDTO findOneByPriceId(Long priceId) {
        return objectMapper.convertValue(priceRepository.findOneByPriceId(priceId),PriceDTO.class);

    }

    @Override
    public PriceDTO findOneByProductId(Long productId) {
        return objectMapper.convertValue(priceRepository.findOneByProductId(productId),PriceDTO.class);
    }


}
