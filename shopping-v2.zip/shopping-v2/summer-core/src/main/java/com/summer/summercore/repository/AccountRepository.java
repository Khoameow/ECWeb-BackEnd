package com.summer.summercore.repository;

import com.summer.summercore.constant.CoreConstant;
import com.summer.summercore.dto.AccountDTO;
import com.summer.summercore.entity.Account;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AccountRepository extends PagingAndSortingRepository<Account,Long> {

    Account findOneByAccountId(Long accountId);
    Account findOneByUsername(String username);

    @Query("update ACCOUNT set DELETED = 1 where ACCOUNT_ID in (:ids)")
    @Modifying
    void updateDeletedAccount(@Param("ids") List<Long> ids);

    @Query(CoreConstant.FIND_ALL_ACCOUNT)
    List<AccountDTO> findAllAccount(@Param("indexLimit")int indexLimit, @Param("indexOffset")long indexOffset);
}
