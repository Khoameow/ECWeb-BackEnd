package com.summer.summercore.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartDTO {

	private Long product;

	private String productName;

	private String imagePresent;
	
	private Double priceValue;
	
	private int stockTotal;
	
	private String qty;
	
	private Date createdDate;

	
}
