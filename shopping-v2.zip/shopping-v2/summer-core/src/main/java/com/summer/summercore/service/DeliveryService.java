package com.summer.summercore.service;

import java.util.List;

import com.summer.summercore.dto.DeliveryDTO;
import com.summer.summercore.entity.Delivery;

public interface DeliveryService {

	int InsertDelivery(Delivery delivery);
	Delivery Store(DeliveryDTO deliveryDTO);
	public DeliveryDTO getDeliverybyIds(Long deliveryId);
	public List<DeliveryDTO> getDeliverybyUserName (String userName);
	public List<DeliveryDTO> getAllDelivery();
	public DeliveryDTO findOneByDeliveryId(Long id);
	DeliveryDTO updateStatus(DeliveryDTO deliveryDTO);
}
