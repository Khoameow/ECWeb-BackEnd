package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductCategoryDTO {

    private Long id;

    private Long categoryId ;

    private Long productId;
}
