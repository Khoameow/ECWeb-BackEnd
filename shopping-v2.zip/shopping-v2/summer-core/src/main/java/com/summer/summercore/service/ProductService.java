package com.summer.summercore.service;

import java.util.List;

import com.summer.summercore.dto.ProductDTO;
import com.summer.summercore.entity.Image;
import com.summer.summercore.entity.Price;
import com.summer.summercore.entity.Product;
import com.summer.summercore.entity.ProductCategory;
import com.summer.summercore.entity.Rating;
import com.summer.summercore.entity.Stock;
import org.springframework.data.domain.Pageable;


public interface ProductService {


    List<ProductDTO> findAllProduct(int indexLimit , int indexOffset);
    Product getProductById(Long productId);
    Product saveProduct(Product product);
    boolean deleteProduct(long id);
    public List<ProductDTO> findAllProductByCategoryId(Long categoryId, int indexLimit , int indexOffset);
    public List<Product> findAllProductTotal();
    
    public List<ProductCategory> findAllProductPresent();
    public List<Product> findAllProductByIds(List<Integer> productIds);
    public List<Image> getProductImageByIds(List<Integer> imageIds);
    public List<Rating> findRatingbyProductId(Long productId);
    public List<Price> findPriceByProductId(Long productId);
    public List<Stock> findStockByProductId(Long productId);
    public List<Image> findImageByProductId(Long productId);
    Long count();
    ProductDTO save(ProductDTO productDTO);
    ProductDTO findOneById(Long id);
	
}
