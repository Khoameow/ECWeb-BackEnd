package com.summer.summercore.service;

import java.util.List;

import com.summer.summercore.dto.CategoryDTO;
import com.summer.summercore.entity.Category;

public interface CategoryService {

	List<CategoryDTO> findAllCategory();
	List<Category> findAllCategoryByIds(List<Integer> categoryIds);
	Category getCategoryById(Long categoryId);
}
