package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "RATING")
public class Rating extends BaseEntity{

    @Id
    @Column(value = "RATING_ID")
    private Long ratingId;

    @Column(value = "PRODUCT_ID")
    private Long productId;

    @Column(value = "RATING_VALUE")
    private Integer ratingValue;





    
}
