package com.summer.summercore.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.summer.summercore.dto.DeliveryDTO;
import com.summer.summercore.entity.Delivery;

public interface DeliveryRepository extends PagingAndSortingRepository<Delivery, Long> {

	@Query("INSERT INTO summer.DELIVERY  (CUSTOMER_NAME, PLACE_DELIVERY, STATUS, DESCRIPTION, ADDRESS, ADDRESS_TYPE, "
			+ "CITY, COUNTRY, LANDMARK, PHONE_NUMBER, PIN_CODE, ITEMS_PRICE, DISCOUNT_PRICE, SHIPPING_PRICE, TOTAL_PRICE, DELETED)\r\n"
			+ "OUTPUT Inserted.DELIVERY_ID VALUES (:customerName, :placeDelivery, :status, :description, :address, :addressType,"
			+ " :city, :country, :landmark, :phoneNumber, :pinCode ,:itemsPrice, :discountPrice, :shippingPrice, :totalPrice, 0);")
	int InsertDelivery(@Param("customerName") String customerName,
			@Param("placeDelivery") String placeDelivery,
			@Param("status") int status, 
			@Param("description") String description, 
			@Param("address") String address,
			@Param("addressType") String addressType, 
			@Param("city") String city,
			@Param("country") String country,
			@Param("landmark") String landmark,
			@Param("phoneNumber") String phoneNumber,
			@Param("pinCode") String pinCode,
			@Param("itemsPrice") Double itemsPrice,
			@Param("discountPrice") Double discountPrice,
			@Param("shippingPrice") Double shippingPrice,
			@Param("totalPrice") Double totalPrice

	);
	
	Delivery findOneByDeliveryId(Long deliveryId);
	
	Delivery findOneByUserName(String userName);
	List<Delivery> findAllByUserName(String userName);

}
