package com.summer.summercore.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManufactureDTO {

    private Long manufactureId;

    private String manufactureName;

}
