package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "PRODUCT")
public class Product extends BaseEntity {

    @Id
    @Column(value = "PRODUCT_ID")
    private Long productId;

    @Column(value = "PRODUCT_NAME")
    private String productName;

    @Column(value = "PRODUCT_CODE")
    private String productCode;

    @Column(value = "LIST_COLOR")
    private String listColor;
    
//    @Column(value = "PRICE_ID")
//    private Long priceId ;
    
    @Column(value = "LIST_PROP")
    private String listProp ;
    
    @Column(value = "RATE_ID")
    private Long rateId ;
    
    @Column(value = "MANUFACTURE_ID")
    private Long manufactureId;
    
    @Column(value = "COUNTRY_ID")
    private Long countryId;
    
    @Column(value = "DECRIPTION")
    private String decription;

}
