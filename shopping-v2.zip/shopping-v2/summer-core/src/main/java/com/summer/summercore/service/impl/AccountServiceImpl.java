package com.summer.summercore.service.impl;

import com.summer.summercore.constant.CoreConstant;
import com.summer.summercore.dto.AccountDTO;
import com.summer.summercore.entity.Account;
import com.summer.summercore.enums.AccountEnum;
import com.summer.summercore.repository.AccountRepository;
import com.summer.summercore.service.AccountService;
import com.summer.summercore.utils.CommonLogUtil;
import com.summer.summercore.utils.SecurityUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class AccountServiceImpl extends BaseService implements AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Override
    public List<AccountDTO> search(String searchKey, Pageable pageable) {
        return accountRepository.findAllAccount(pageable.getPageSize(),pageable.getOffset());
    }

    @Override
    public long count() {
        return accountRepository.count();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public AccountDTO save(AccountDTO accountDto) {
        try {
            Account account = objectMapper.convertValue(accountDto, Account.class);
            Long id = account.getAccountId();
            if(null != id){
                Account accountDb = accountRepository.findOneByAccountId(id);
                account.setCreatedBy(accountDb.getCreatedBy());
                account.setCreatedDate(accountDb.getCreatedDate());
                account.setUpdatedBy(SecurityUtil.getPrincipal().getUsername());
                account.setUpdatedDate(new Date(System.currentTimeMillis()));
            }
            else{
                account.setCreatedBy(SecurityUtil.getPrincipal().getUsername());
                account.setCreatedDate(new Date(System.currentTimeMillis()));
            }
            return objectMapper.convertValue(accountRepository.save(account), AccountDTO.class);
        }catch (Exception e){
            CommonLogUtil.logError(e);
        }
        return null;
    }

    @Override
    public AccountDTO findOneByUsername(String username) {
        return objectMapper.convertValue(accountRepository.findOneByUsername(username), AccountDTO.class);
    }

    @Override
    public AccountDTO findOneById(Long id) {
        return objectMapper.convertValue(accountRepository.findOneByAccountId(id), AccountDTO.class);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteAccount(List<Long> ids) {
        accountRepository.updateDeletedAccount(ids);
    }

}
