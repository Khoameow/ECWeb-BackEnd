package com.summer.summercore.repository;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.summer.summercore.entity.DeliveryProduct;

public interface DeliveryProductRepository extends PagingAndSortingRepository<DeliveryProduct, Long> {
	 @Query("select * from DELIVERY_PRODUCT where DELIVERY_ID = :deliveryId;")
	List<DeliveryProduct> getDeliveryProductByDeliveryId(@Param("deliveryId") Long deliveryId);
}
