package com.summer.summercore.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "AUTH")
public class Auth extends BaseEntity {

    @Id
    @Column(value = "AUTH_ID")
    private Long authId;

    @Column(value = "ACCOUNT_ID")
    private Long accountId;

    @Column(value = "USERNAME")
    private String username;

    @Column(value = "PASSWORD")
    private String password;

    @Column(value = "TYPE")
    private String type;

    @Column(value = "EMAIL")
    private String email;
}
