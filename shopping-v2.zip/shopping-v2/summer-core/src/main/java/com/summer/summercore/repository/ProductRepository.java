package com.summer.summercore.repository;

import java.util.List;

import com.summer.summercore.constant.CoreConstant;
import com.summer.summercore.dto.ProductDTO;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.summer.summercore.entity.Image;
import com.summer.summercore.entity.Price;
import com.summer.summercore.entity.Product;
import com.summer.summercore.entity.ProductCategory;
import com.summer.summercore.entity.Rating;
import com.summer.summercore.entity.Stock;


public interface ProductRepository extends PagingAndSortingRepository<Product, Long> {

	@Query(CoreConstant.FIND_ALL_PRODUCT)
    List<ProductDTO> findAllProduct(@Param("indexLimit") Integer indexLimit , @Param ("indexOffset") Integer indexOffset);
	
	@Query("select * from PRODUCT where PRODUCT_ID = :productId;")
    Product getProductById(@Param("productId") Long productId);

//	@Query("INSERT INTO product (product_id, product_name, prices, is_delete, image, color, manufacture_id, category_id, decription)\r\n"
//			+ "VALUES (:productId, :productName, :prices, 1, :image, :color, :manufactureId, :categoryId);")
//	void InsertProduct(	@Param("productId") Long productId,
//									@Param("productName") String productName,
//									@Param("prices") String prices,
//									@Param("image") String image,
//									@Param("color") String color,
//									@Param("manufactureId") Long manufactureId,
//									@Param("categoryId") Long categoryId);
	
	
//	@Query("UPDATE product\r\n"
//			+ "SET product_name =  :productName, prices = :prices, image = :image, color = :color, :manufacture_id = :manufactureId, category_id= :categoryId"
//			+ "WHERE product_id = :productId;")
//	void UpdateProduct(	@Param("productId") Long productId,
//									@Param("productName") String productName,
//									@Param("prices") String prices,
//									@Param("image") String image,
//									@Param("color") String color,
//									@Param("manufactureId") Long manufactureId,
//									@Param("categoryId") Long categoryId);
//	@Query("UPDATE product\r\n"
//			+ "SET is_delete = 0"
//			+ "WHERE productId = :productId;")
//	void DeleteProduct(	@Param("productId") Long productId );

	@Query(CoreConstant.FIND_ALL_PRODUCT_BY_CATEGORY)
    List<ProductDTO> findAllProductByCategoryId(@Param("categoryId") Long categoryId, @Param("indexLimit") Integer indexLimit , @Param ("indexOffset") Integer indexOffset);
	
	@Query("select * from product order by product_id")
    List<Product> findAllProductTotal();
	
	
	@Query("select * from PRODUCT_CATEGORY limit 4")
    List<ProductCategory> findAllProductPresent();
	
	@Query("SELECT * FROM PRODUCT WHERE PRODUCT_ID IN  ( :productIds)")
	 List<Product> findAllProductByIds(@Param("productIds") List<Integer> productIds);
	
	 @Query("select * from PRODUCT_IMAGE where IMAGE_ID IN  ( :imageIds)")
	 List<Image>  getProductImageByIds(@Param("imageIds") List<Integer> imageIds);
	
	@Query("SELECT * FROM RATING WHERE PRODUCT_ID = :productId")
	 List<Rating> findRatingbyProductId(@Param("productId") Long productId);
	
	@Query("SELECT * FROM PRODUCT_PRICE WHERE PRODUCT_ID = :productId")
	 List<Price> findPriceByProductId(@Param("productId") Long productId);
	
	@Query("select * from PRODUCT_STOCK where PRODUCT_ID = :productId")
	 List<Stock> findStockByProductId(@Param("productId") Long productId);

	@Query("select count(*) from PRODUCT where DELETED = 0")
    Long countAllProduct();

	@Query("select * from PRODUCT_IMAGE where PRODUCT_ID = :productId")
	 List<Image> findImageByProductId(@Param("productId") Long productId);

	@Query(CoreConstant.FIND_ONE_PRODUCT)
	ProductDTO findOneByProductId(@Param("productId") Long productId);

	@Modifying
	@Query("UPDATE PRODUCT p SET p.DELETED = 1 WHERE p.PRODUCT_ID = :productId")
	void deleteProductById(@Param("productId") Long productId);

}
