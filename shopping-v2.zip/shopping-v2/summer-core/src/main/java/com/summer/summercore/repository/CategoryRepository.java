package com.summer.summercore.repository;

import com.summer.summercore.dto.CategoryDTO;
import com.summer.summercore.entity.Category;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CategoryRepository extends PagingAndSortingRepository<Category,Long> {

	 @Query("SELECT * FROM CATEGORY")
	 List<CategoryDTO> findAllCategory();
	 
	 @Query("SELECT * FROM CATEGORY WHERE CATEGORY_ID IN  ( :categoryIds)")
	 List<Category> findAllCategoryByIds(@Param("categoryIds") List<Integer> categoryIds);
	 
	 @Query("select * from CATEGORY where CATEGORY_ID = :categoryId;")
	 Category getCategoryById(@Param("categoryId") Long categoryId);
}
