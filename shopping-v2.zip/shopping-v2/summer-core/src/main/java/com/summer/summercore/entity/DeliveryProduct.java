package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "DELIVERY_PRODUCT")
public class DeliveryProduct extends BaseEntity{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(value = "DELIVERY_PRODUCT_ID")
    private Long deliveryProductId;
	
    @Column(value = "DELIVERY_ID")
    private Long deliveryId;

    @Column(value = "PRODUCT_ID")
    private Long productId;
    
    @Column(value = "QUANLITY")
    private Integer quanlity;


    
}
