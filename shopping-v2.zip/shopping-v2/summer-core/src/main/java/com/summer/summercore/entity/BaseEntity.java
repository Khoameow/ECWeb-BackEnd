package com.summer.summercore.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.data.relational.core.mapping.Column;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@MappedSuperclass
//@EntityListeners({AuditingEntityListener.class})
public abstract class BaseEntity implements Serializable {

//    @Id
//    @Column(value = "ID")
//    private Long id;

//    @CreatedDate
    @Column(value = "CREATED_DATE")
    private Date createdDate;

//    @CreatedBy
    @Column(value = "CREATED_BY")
    private String createdBy;

//    @LastModifiedDate
    @Column(value = "UPDATED_DATE")
    private Date updatedDate;

//    @LastModifiedBy
    @Column(value = "UPDATED_BY")
    private String updatedBy;

    @Column(value = "DELETED")
    private Integer deleted = 0;
}
