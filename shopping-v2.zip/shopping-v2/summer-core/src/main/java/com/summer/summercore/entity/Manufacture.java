package com.summer.summercore.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@Table(name = "MANUFACTURE")
public class Manufacture extends BaseEntity{

    @Id
    @Column(value = "MANUFACTURE_ID")
    private Long manufactureId;

    @Column(value = "MANUFACTURE_NAME")
    private String manufactureName;


    
    
    
	
}
