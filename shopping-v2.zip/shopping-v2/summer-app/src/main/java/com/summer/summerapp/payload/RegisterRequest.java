package com.summer.summerapp.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegisterRequest {
    private String yourName;
    private String email;
    private String password;
}
