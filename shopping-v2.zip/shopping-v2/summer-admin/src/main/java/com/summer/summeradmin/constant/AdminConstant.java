package com.summer.summeradmin.constant;

public class AdminConstant {
    public static final int PAGE_SIZE = 20;
    public static final String DATA_FORM = "dataForm";
    public static final String MESSAGE = "message";
    public static final String ALERT = "alert";

    public static final String PAGE_MODEL = "pageModel";
    public static final String ROOT = "/admin";
    public static final String API = "/admin/api";
}
