package com.summer.summeradmin.controller;


import com.summer.summercore.dto.AuthDTO;
import com.summer.summercore.service.AuthService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class LoginController {


    @Autowired
    private AuthService authService;

    @GetMapping(value = "/login")
    public ModelAndView login(
            @RequestParam(value = "message",required = false) String message,
            @RequestParam(value = "error",required = false) boolean error,
            @RequestParam(value = "logout",required = false) boolean logout
    ){
        ModelAndView mav = new ModelAndView("views/login");
        if(error){
            message = "Invalid username and password.";
        }
        if(logout){
            message = "You have been logged out.";
        }
        mav.addObject("message",message);
        return mav;
    }

    @PostMapping(value = "/register")
    public ModelAndView register(
        @RequestParam(value = "username") String username,
        @RequestParam(value = "email") String email,
        @RequestParam(value = "password") String password,
        @RequestParam(value = "repeatPassword") String repeatPassword
    ){
        String message = "";

        if(StringUtils.isBlank(username) || StringUtils.isBlank(email) || StringUtils.isBlank(password)){
            message = "Field can not empty";
            return new ModelAndView("redirect:login?message=" + message);
        }

        if(!password.equals(repeatPassword)){
            message = "password and repeat password is not correct";
            return new ModelAndView("redirect:login?message=" + message);
        }

        if(authService.usernameIsExist(username)){
            message = "username is exist";
            return new ModelAndView("redirect:login?message=" + message);
        }

        AuthDTO authDto = new AuthDTO();
        authDto.setUsername(username);
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        authDto.setPassword(passwordEncoder.encode(password));
        authDto = authService.registry(authDto);

        if(null != authDto.getAuthId()){
            message = "Register Success";
        }
        else{
            message = "Register Error";
        }



        return new ModelAndView("redirect:login?message=" + message);
    }

}
