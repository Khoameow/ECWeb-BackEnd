package com.summer.summeradmin.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summeradmin.constant.AdminConstant;
import com.summer.summeradmin.model.PageModel;
import com.summer.summeradmin.utils.MessageUtil;
import com.summer.summercore.dto.AccountDTO;
import com.summer.summercore.entity.Auth;
import com.summer.summercore.repository.AuthRepository;
import com.summer.summercore.service.AccountService;
import com.summer.summercore.service.AuthService;
import com.summer.summercore.utils.CommonLogUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;

/*Only account have role ADMIN access*/
@RestController
@RequestMapping(value = AdminConstant.ROOT)
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private AuthRepository authRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MessageUtil messageUtil;


    @GetMapping(value = "/account/list")
    public ModelAndView listAccount(
            @RequestParam(value = "pageIndex",required = false)     Optional<Integer>   pageIndex,
            @RequestParam(value = "pageSize",required = false)      Optional<Integer>   pageSize,
            @RequestParam(value = "sortName",required = false)      Optional<String>    sortName,
            @RequestParam(value = "sortBy",required = false)        Optional<String>    sortBy,
            @RequestParam(value = "searchKey",required = false)     Optional<String>    searchKey,
            @RequestParam(value = "messageCode",required = false)   Optional<String>    messageCode
    ){
        ModelAndView mav = new ModelAndView("views/account/list");

        PageModel pageModel = new PageModel();
        pageModel.setPageIndex(pageIndex.orElse(1));
        pageModel.setPageSize(pageSize.orElse(10));
        pageModel.setSortName(sortName.orElse("desc"));
        pageModel.setSortBy(sortBy.orElse("id"));
        pageModel.setSearchKey(searchKey.orElse(StringUtils.EMPTY));
        pageModel.setTotalPage(accountService.count()/pageModel.getPageSize());


        Pageable pageable = PageRequest.of(pageModel.getPageIndex()-1, pageModel.getPageSize(),
                Sort.Direction.valueOf(StringUtils.upperCase(pageModel.getSortName())),
                StringUtils.upperCase(pageModel.getSortBy())
        );


        List<AccountDTO> listResults = accountService.search(pageModel.getSearchKey(),pageable);


        mav.addObject(AdminConstant.PAGE_MODEL,pageModel);

        if(messageCode.isPresent()){
            Map<String,String> message = messageUtil.getMessage(messageCode.get());
            mav.addObject(AdminConstant.MESSAGE,message.get("message"));
            mav.addObject(AdminConstant.ALERT,message.get("alert"));
        }

        pageModel.setListResults(listResults);
        return mav;
    }



    @GetMapping(value = "/account/delete")
    public ModelAndView deleteAccount(@RequestParam(value = "id",required = false) Long id){
        String messageCode = "";
        try {
            List<Long> ids = Arrays.asList(id);
            authRepository.deleteAuth(id);
            accountService.deleteAccount(ids);
            messageCode = "delete_success";
        }catch (Exception e){
            CommonLogUtil.logError(e);
            messageCode = "error_system";
        }
        return new ModelAndView("redirect:list?messageCode="+messageCode);
    }


    @GetMapping(value = "/account/edit")
    public ModelAndView editAccount(
            @RequestParam(value = "id",required = false) Long id,
            @RequestParam(value = "messageCode",required = false) String messageCode
    ){
        ModelAndView mav = new ModelAndView("views/account/edit");
        AccountDTO accountDto = new AccountDTO();
        if(Objects.nonNull(id)){
            accountDto = accountService.findOneById(id);
        }

        mav.addObject(AdminConstant.DATA_FORM,accountDto);

        if(Objects.nonNull(messageCode)){
            Map<String,String> message = messageUtil.getMessage(messageCode);
            mav.addObject(AdminConstant.MESSAGE,message.get("message"));
            mav.addObject(AdminConstant.ALERT,message.get("alert"));
        }
        return mav;
    }



    @PostMapping(value = "/account/edit")
    public ModelAndView createAndUpdateAccount(
            @ModelAttribute(AdminConstant.DATA_FORM) AccountDTO accountDto
    ){
        String messageCode = "";
        try {
            //Validate
//        if(
//                StringUtils.isBlank(accountModel.getUsername()) ||
//                StringUtils.isBlank(accountModel.getEmail()) ||
//                StringUtils.isBlank(accountModel.getPassword()) ||
//                StringUtils.isBlank(accountModel.getFullname()) ||
//                StringUtils.isBlank(accountModel.getGender())
//        ){
//            message = "Field can not empty";
//            return new ModelAndView("redirect:edit?message=" + message);
//        }

            if(Objects.isNull(accountDto.getAccountId()) && Objects.nonNull(accountService.findOneByUsername(accountDto.getUsername()))){
                messageCode = "account_exist";
                return new ModelAndView("redirect:edit?messageCode=" + messageCode);
            }
            String password = accountDto.getPassword();
            Long accountId = accountDto.getAccountId();
            accountDto = accountService.save(accountDto);

            if(Objects.nonNull(accountId)){
                messageCode = "update_success";
                Auth auth = authRepository.findOneByAccountId(accountDto.getAccountId());
                PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                auth.setPassword(passwordEncoder.encode(password));
                authRepository.save(auth);
            }
            else{
                messageCode = "insert_success";
                Auth auth = new Auth();
                auth.setAccountId(accountDto.getAccountId());
                auth.setType("BASIC_LOGIN");
                auth.setUsername(accountDto.getUsername());
                PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
                auth.setPassword(passwordEncoder.encode(password));
                authRepository.save(auth);
            }



        }catch (Exception e){
            CommonLogUtil.logError(e);
            messageCode = "error_system";
        }
        return new ModelAndView("redirect:edit?id="+accountDto.getAccountId()+"&messageCode="+messageCode);
    }

}
