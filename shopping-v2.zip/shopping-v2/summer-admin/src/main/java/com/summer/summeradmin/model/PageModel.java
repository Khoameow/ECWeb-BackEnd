package com.summer.summeradmin.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PageModel {

    protected String searchKey;
    protected Integer pageIndex;
    protected Integer pageSize;
    protected String sortBy;
    protected String sortName;
    protected Long totalPage;
    protected String message;
    protected Object listResults;

}
