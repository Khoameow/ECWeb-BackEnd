package com.summer.summeradmin.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/*Redirect when the first time access*/
@RestController
public class BaseController {


    @GetMapping(value = "/")
    public ModelAndView index(){
        return new ModelAndView("redirect:login");
    }


    @GetMapping(value = "/admin")
    public ModelAndView adminPage(){
        ModelAndView mav = new ModelAndView("views/home");
        return mav;
    }

}
