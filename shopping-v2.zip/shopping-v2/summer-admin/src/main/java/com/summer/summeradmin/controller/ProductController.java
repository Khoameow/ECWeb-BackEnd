package com.summer.summeradmin.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.summer.summeradmin.constant.AdminConstant;
import com.summer.summeradmin.model.PageModel;
import com.summer.summeradmin.utils.MessageUtil;
import com.summer.summercore.dto.PriceDTO;
import com.summer.summercore.dto.ProductCategoryDTO;
import com.summer.summercore.dto.ProductDTO;
import com.summer.summercore.entity.Image;
import com.summer.summercore.entity.Rating;
import com.summer.summercore.entity.Stock;
import com.summer.summercore.repository.ImageRepository;
import com.summer.summercore.repository.ProductCategoryRepository;
import com.summer.summercore.repository.RatingRepository;
import com.summer.summercore.repository.StockRepository;
import com.summer.summercore.service.*;
import com.summer.summercore.utils.CommonLogUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;

@RestController
@RequestMapping(value = AdminConstant.ROOT)
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private ImageRepository imageRepository;

    @Autowired
    private StockRepository stockRepository;


    @Autowired
    private ProductPriceService productPriceService;

    @Autowired
    private ProductColorService productColorService;

    @Autowired
    private ProductPropService productPropService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ManufactureService manufactureService;

    @Autowired
    private ProductCategoryService productCategoryService;


    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MessageUtil messageUtil;


    @GetMapping(value = "/product/list")
    public ModelAndView listProduct(
            @RequestParam(value = "pageIndex",required = false) Optional<Integer> pageIndex,
            @RequestParam(value = "pageSize",required = false)      Optional<Integer>   pageSize,
            @RequestParam(value = "sortName",required = false)      Optional<String>    sortName,
            @RequestParam(value = "sortBy",required = false)        Optional<String>    sortBy,
            @RequestParam(value = "searchKey",required = false)     Optional<String>    searchKey,
            @RequestParam(value = "messageCode",required = false)   Optional<String>    messageCode
    ){
        ModelAndView mav = new ModelAndView("views/product/list");

        PageModel pageModel = new PageModel();
        pageModel.setPageIndex(pageIndex.orElse(1));
        pageModel.setPageSize(pageSize.orElse(10));
        pageModel.setSortName(sortName.orElse("desc"));
        pageModel.setSortBy(sortBy.orElse("id"));
        pageModel.setSearchKey(searchKey.orElse(StringUtils.EMPTY));
        pageModel.setTotalPage(productService.count()/pageModel.getPageSize());


        Pageable pageable = PageRequest.of(pageModel.getPageIndex()-1, pageModel.getPageSize(),
                Sort.Direction.valueOf(StringUtils.upperCase(pageModel.getSortName())),
                StringUtils.upperCase(pageModel.getSortBy())
        );


        List<ProductDTO> listResults = productService.findAllProduct(pageable.getPageSize(), (int) pageable.getOffset());


        mav.addObject(AdminConstant.PAGE_MODEL,pageModel);

        if(messageCode.isPresent()){
            Map<String,String> message = messageUtil.getMessage(messageCode.get());
            mav.addObject(AdminConstant.MESSAGE,message.get("message"));
            mav.addObject(AdminConstant.ALERT,message.get("alert"));
        }

        pageModel.setListResults(listResults);
        return mav;
    }


    @GetMapping(value = "/product/edit")
    public ModelAndView editProduct(
            @RequestParam(value = "id",required = false) Long id,
            @RequestParam(value = "messageCode",required = false) String messageCode
    ){
        ModelAndView mav = new ModelAndView("views/product/edit");
        ProductDTO productDTO = new ProductDTO();
        if(Objects.nonNull(id)){
            productDTO = productService.findOneById(id);
            PriceDTO priceDTO = productPriceService.findOneByPriceId(productDTO.getPriceId());
            if(priceDTO != null){
                productDTO.setPriceValue(priceDTO.getPriceOut());
            }
            else{
                productDTO.setPriceValue(500D);
            }
        }
        mav.addObject(AdminConstant.DATA_FORM,productDTO);

        mav.addObject("listColorDto",productColorService.findAllProductColor());
        mav.addObject("listProductPropDto",productPropService.findAllProductProp());
        mav.addObject("listManufactureDto",manufactureService.findAllManufacture());
        mav.addObject("listCategoryDto",categoryService.findAllCategory());

        List<String> arrayListColor = new ArrayList();
        List<String> arrayListProp = new ArrayList();

        if(Objects.nonNull(id)){
            arrayListColor = Arrays.asList(productDTO.getListColor().split(","));
            arrayListProp = Arrays.asList(productDTO.getListProp().split(","));
        }
        mav.addObject("arrayListColor",arrayListColor);
        mav.addObject("arrayListProp",arrayListProp);

        if(Objects.nonNull(messageCode)){
            Map<String,String> message = messageUtil.getMessage(messageCode);
            mav.addObject(AdminConstant.MESSAGE,message.get("message"));
            mav.addObject(AdminConstant.ALERT,message.get("alert"));
        }
        return mav;
    }




    @PostMapping(value = "/product/edit")
    public ModelAndView createAndUpdateProduct(
            @ModelAttribute(AdminConstant.DATA_FORM)ProductDTO productDTO
    ){
        String messageCode = "";
        try {
        	
        	//Validate
        	if(validate(productDTO)) {
        		messageCode = "validate_code";
        		return new ModelAndView("redirect:edit?&messageCode="+messageCode);
        	}

            Long productId = productDTO.getProductId();

            /*Store category*/
            Long categoryId = productDTO.getCategoryId();
            String imageLink = productDTO.getImageLink();
            Double priceValue = productDTO.getPriceValue();

            if(Objects.nonNull(productId)){
                messageCode = "update_success";

                /*Save Price*/
                PriceDTO priceDTO = productPriceService.findOneByProductId(productDTO.getProductId());
                priceDTO.setPriceOut(productDTO.getPriceValue());
                productPriceService.save(priceDTO);

                /*Save Category of product*/
                List<ProductCategoryDTO> listProductCategoryDTO = productCategoryService.findAllByProductId(productDTO.getProductId());
                for(ProductCategoryDTO item : listProductCategoryDTO){
                    item.setCategoryId(categoryId);
                    productCategoryService.save(item);
                }

                /*Save Image*/
                Image image = imageRepository.findOneByProductId(productDTO.getProductId());
                if(StringUtils.isNotBlank(productDTO.getImageLink())){
                    image.setImageLink(productDTO.getImageLink());
                    imageRepository.save(image);
                }


                /*Save Product*/
                productDTO = productService.save(productDTO);

            }
            else{
                messageCode = "insert_success";

                /*Save Product*/
                productDTO = productService.save(productDTO);

                /*Save Price*/
                PriceDTO priceDTO = new PriceDTO();
                priceDTO.setProductId(productDTO.getProductId());
                if(priceValue != null){
                    priceDTO.setPriceOut(priceValue);
                }
                else{
                    priceDTO.setPriceOut(10000D);
                }
                productPriceService.save(priceDTO);

                /*Save Image*/
                Image image = new Image();
                image.setProductId(productDTO.getProductId());
                image.setImageLink(imageLink);
                image.setImageName("Anh");
                image.setImageType(1);
                imageRepository.save(image);

                /*Save Stock*/
                Stock stock = new Stock();
                stock.setProductId(productDTO.getProductId());
                stock.setTotal(100);
                stock.setColorId(1L);
                stockRepository.save(stock);

                /*Save Category of product*/
                ProductCategoryDTO productCategoryDTO = new ProductCategoryDTO();
                productCategoryDTO.setProductId(productDTO.getProductId());
                productCategoryDTO.setCategoryId(categoryId);
                productCategoryService.save(productCategoryDTO);

                /*Save Ratting*/
                Rating rating = new Rating();
                rating.setProductId(productDTO.getProductId());
                rating.setRatingValue(5);
                ratingRepository.save(rating);

            }

        }catch (Exception e){
            CommonLogUtil.logError(e);
            messageCode = "error_system";
        }
        return new ModelAndView("redirect:edit?id="+productDTO.getProductId()+"&messageCode="+messageCode);
    }


    private boolean validate(ProductDTO productDTO) {
    	
		if(StringUtils.isBlank(productDTO.getProductCode())) {
			return true;
		}
		
		if(StringUtils.isBlank(productDTO.getProductCode())) {
			return true;
		}
		
		if(StringUtils.isBlank(productDTO.getListColor())) {
			return true;
		}
		
		
		if(Objects.isNull(productDTO.getPriceValue())) {
			return true;
		}
		
		if(StringUtils.isBlank(productDTO.getImageLink())) {
			return true;
		}
		
		
		if(StringUtils.isBlank(productDTO.getListProp())) {
			return true;
		}
		
		
		return false;
	}


	@GetMapping(value = "/product/delete")
    public ModelAndView deleteProduct(@RequestParam(value = "id",required = false) Long id){
        String messageCode = "";
        try {
            productService.deleteProduct(id);
            messageCode = "delete_success";
        }catch (Exception e){
            CommonLogUtil.logError(e);
            messageCode = "error_system";
        }
        return new ModelAndView("redirect:list?messageCode="+messageCode);
    }
}
