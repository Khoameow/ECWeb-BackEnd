package com.summer.summeradmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;

@SpringBootApplication
@ComponentScan(value = {"com.summer.summeradmin","com.summer.summercore"})
@EnableJdbcRepositories(basePackages={"com.summer.summercore.repository"})
public class SummerAdmin {

    public static void main(String[] args) {
        SpringApplication.run(SummerAdmin.class, args);
    }
}
