create table ACCOUNT
(
    ID           bigint auto_increment
        primary key,
    USERNAME     varchar(255) not null,
    FULLNAME     varchar(255) null,
    EMAIL        varchar(255) null,
    GENDER       varchar(30)  null,
    CREATED_DATE datetime     null,
    CREATED_BY   varchar(255) null,
    UPDATED_DATE datetime     null,
    UPDATED_BY   varchar(255) null,
    DELETED      tinyint(1)   null
);

create table AUTH
(
    ID           bigint auto_increment
        primary key,
    ACCOUNT_ID   bigint       null,
    USERNAME     varchar(255) not null,
    PASSWORD     varchar(255) not null,
    TYPE         varchar(30)  null,
    CREATED_DATE datetime     null,
    CREATED_BY   varchar(255) null,
    UPDATED_DATE datetime     null,
    UPDATED_BY   varchar(255) null,
    DELETED      tinyint(1)   null
);

